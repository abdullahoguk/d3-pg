void logProgram ( char *progName ) ;
