void freePlotRec ( struct plotRec *rec ) ;
void addPlotToTitleSearch (struct titleSearchRec *tchain) ;
