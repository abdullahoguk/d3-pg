void freeTrivia ( struct lineRec *rec ) ;
void addTriviaToTitleSearch (struct titleSearchRec *tchain) ;
