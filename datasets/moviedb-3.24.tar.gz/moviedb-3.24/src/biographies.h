void freePersonRec ( struct personRec *rec ) ;
void addBiographiesToNameSearch (struct nameSearchRec *chain) ;
