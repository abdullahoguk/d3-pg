void addCastCompleteStatusToTitleSearch ( struct titleSearchRec *tchain ) ;
void addCrewCompleteStatusToTitleSearch ( struct titleSearchRec *tchain ) ;
