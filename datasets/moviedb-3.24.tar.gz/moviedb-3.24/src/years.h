void addYearsToNameSearch (struct nameSearchRec *chain) ;
void addYearsToTitleSearch (struct titleSearchRec *tchain) ;
int yearLformatSort ( struct formatRec *r1, struct formatRec *r2 ) ;
TitleID readTitleDb ( struct titleDbRec array [] ) ;
