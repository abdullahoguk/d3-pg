int minimal_distance (char *x, char *y, int case_sens) ;
