void freeLiterature ( struct lineRec *data ) ;
void addLiteratureToTitleSearch (struct titleSearchRec *tchain) ;
