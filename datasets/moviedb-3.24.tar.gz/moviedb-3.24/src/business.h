void freeBusiness ( struct lineRec *data ) ;
void addBusinessToTitleSearch (struct titleSearchRec *tchain) ;
