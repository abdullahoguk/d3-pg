void addTimesToTitleSearch (struct titleSearchRec *tchain) ;
