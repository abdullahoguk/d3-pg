void freeMovieLinks ( int noOfEntries, struct movieLinkRec *rec ) ;
void addMovieLinksToTitleSearch ( struct titleSearchRec *tchain ) ;
