struct akaRec *cloneAkaData ( struct akaRec *aka ) ;
void addAkaToNameSearch (struct nameSearchRec *chain) ;
void addAkaToTitleSearch (struct titleSearchRec *tchain) ;
void addNameAkaToNameSearch (struct nameSearchRec *nchain) ;
