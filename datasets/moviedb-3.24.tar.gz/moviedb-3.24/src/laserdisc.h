void freeLaserRec ( struct laserRec *rec ) ;
void addLaserDiscToTitleSearch (struct titleSearchRec *tchain) ;
